# pmtc_python_common_models

This repository is using for create common model classes.
create a tar file or an executable file using the command 
"python setup.py sdist" this will create a tar.gz file.
This tar file can install in other services by using the command
"pip install common_utils-1.0.tar.gz"