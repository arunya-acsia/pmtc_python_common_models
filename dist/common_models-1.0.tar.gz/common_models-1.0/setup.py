from setuptools import setup, find_packages

setup(
    name="common_models",
    version="1.0",
    author="AutoSMACT",
    packages=find_packages()
)